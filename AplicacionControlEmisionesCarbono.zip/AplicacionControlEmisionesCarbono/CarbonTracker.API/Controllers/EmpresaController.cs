﻿using Microsoft.AspNetCore.Mvc;
using CarbonTracker.Application.Interfaces;
using CarbonTracker.Domain.Entities;

namespace CarbonTracker.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmpresaController : ControllerBase
    {
        private readonly IEmpresaService _empresaService;

        public EmpresaController(IEmpresaService empresaService)
        {
            _empresaService = empresaService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var empresas = await _empresaService.ObtenerEmpresasAsync();
            return Ok(empresas);
        }

        [HttpPost]
        public async Task<IActionResult> Post(Empresa empresa)
        {
            var creada = await _empresaService.CrearEmpresaAsync(empresa);
            return CreatedAtAction(nameof(Get), new { id = creada.EmpresaId }, creada);
        }
    }
}

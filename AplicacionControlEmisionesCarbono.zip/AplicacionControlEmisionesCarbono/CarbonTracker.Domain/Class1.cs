﻿namespace CarbonTracker.Domain
{
    public class Class1
    {

    }
}

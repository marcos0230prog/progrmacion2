﻿namespace CarbonTracker.Domain.Entities
{
    public class Sugerencia
    {
        public int SugerenciaId { get; set; }
        public int EmpresaId { get; set; }
        public string? Descripcion { get; set; }
        public string? Estado { get; set; }

        public Empresa? Empresa { get; set; }
    }
}

﻿namespace CarbonTracker.Domain.Entities
{
    public class Emision
    {
        public int EmisionId { get; set; }
        public int EmpresaId { get; set; }
        public DateTime Fecha { get; set; }
        public string? Fuente { get; set; }
        public decimal Cantidad { get; set; }
        public string? Unidad { get; set; }

        public Empresa? Empresa { get; set; }
    }
}

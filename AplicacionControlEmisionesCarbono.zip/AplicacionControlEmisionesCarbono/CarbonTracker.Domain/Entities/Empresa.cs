﻿namespace CarbonTracker.Domain.Entities
{
    public class Empresa
    {
        public int EmpresaId { get; set; }
        public string? Nombre { get; set; }
        public string? RUC { get; set; }
        public string? Direccion { get; set; }
    }
}

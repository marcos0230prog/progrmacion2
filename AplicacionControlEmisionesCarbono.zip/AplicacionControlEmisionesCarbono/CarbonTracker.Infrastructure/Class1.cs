﻿namespace CarbonTracker.Infrastructure
{
    public class Class1
    {

    }
}

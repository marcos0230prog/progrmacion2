﻿using CarbonTracker.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace CarbonTracker.Infrastructure.Persistence
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Empresa> Empresas { get; set; }
        public DbSet<Emision> Emisiones { get; set; }
        public DbSet<Sugerencia> Sugerencias { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Empresa>().ToTable("Empresas");
            modelBuilder.Entity<Emision>().ToTable("Emisiones");
            modelBuilder.Entity<Sugerencia>().ToTable("Sugerencias");
        }
    }
}

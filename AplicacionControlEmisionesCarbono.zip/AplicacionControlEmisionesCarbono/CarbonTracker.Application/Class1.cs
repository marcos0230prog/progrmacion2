﻿namespace CarbonTracker.Application
{
    public class Class1
    {

    }
}

﻿using CarbonTracker.Application.Interfaces;
using CarbonTracker.Domain.Entities;
using CarbonTracker.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace CarbonTracker.Application.Services
{
    public class EmpresaService : IEmpresaService
    {
        private readonly AppDbContext _context;

        public EmpresaService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Empresa>> ObtenerEmpresasAsync()
        {
            return await _context.Empresas.ToListAsync();
        }

        public async Task<Empresa> CrearEmpresaAsync(Empresa empresa)
        {
            _context.Empresas.Add(empresa);
            await _context.SaveChangesAsync();
            return empresa;
        }
    }
}

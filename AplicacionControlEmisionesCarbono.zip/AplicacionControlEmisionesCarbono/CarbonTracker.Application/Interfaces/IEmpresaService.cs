﻿using CarbonTracker.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarbonTracker.Application.Interfaces
{
    public interface IEmpresaService
    {
        Task<List<Empresa>> ObtenerEmpresasAsync();
        Task<Empresa> CrearEmpresaAsync(Empresa empresa);
    }
}
